-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here



Background = display.newImage("Background.jpg",160,250)
Background.yScale = 0.8
Background.xScale = 0.8

Ship = display.newImage("Ship 1.png", 160, 250)
Ship.xScale = 0.3
Ship.yScale = 0.3

Life1 = display.newImage("Life,png" , 400, 30)

Shadow = display.newImage("ass.png", Ship.x,Ship.y)
Shadow.xScale = 0.2
Shadow.yScale = 0.3
Shadow.alpha = 0.5

BombSound = audio.loadSound("Bomb.mp3")
COLLECT = audio.loadSound("collect.mp3")
SNOWS = audio.loadSound("SNOW.mp3")
sound = audio.loadSound("Sound.mp3")
LASERSOUND = audio.loadSound("Laser Blast.mp3")
Portalsound = audio.loadSound("SSS.mp3")
music = audio.loadSound("Tetris.mp3")
setting = {}
setting.loops = -1
channel = audio.play(music, setting)

Enemie = display.newGroup()
Fire = display.newGroup()
Fire1 = display.newGroup()
iceorbs = display.newGroup()
Bullet = display.newGroup()
portal = display.newGroup()
laser = display.newGroup()
Ebullet = display.newGroup()
gems = display.newGroup()
LaserOrb = display.newGroup()
Bomb3 = display.newGroup()
snows = display.newGroup()
mainGroup = display.newGroup()


mainGroup:insert(Background)
mainGroup:insert(gems)
mainGroup:insert(Shadow)
mainGroup:insert(Enemie)
mainGroup:insert(Fire)
mainGroup:insert(Fire1)
mainGroup:insert(Bomb3)
mainGroup:insert(LaserOrb)
mainGroup:insert(iceorbs)
mainGroup:insert(portal)
mainGroup:insert(laser)
mainGroup:insert(Ebullet)
mainGroup:insert(Bullet)
mainGroup:insert(Ship)
mainGroup:insert(snows)
-----------------------------------------------------------------------------------------
--Gem--

function GenGems(E1)
    gem = display.newImage("Gem.png",E1.x,E1.y)
    gem.xScale = 0.05
    gem.yScale = 0.05
    gems:insert(gem)
end

function DeleteGem(Dgem)
    Dgem:removeSelf()
    Dgem = nil
end
-----------------------------------------------------------------------------------------
function GenGameOver()
    Game = display.newImage("gameover.png",155,190)
    Game.xScale = 0.7
    Game.yScale = 0.7
end

-----------------------------------------------------------------------------------------
-- Gen Snow -- 

function GenSnow()
    if math.random(1,10) == 1 then
        snow = display.newImage("Snow.png", math.random(-10,500), math.random(-30,-10))
        Random = math.random(1,5)/200
        snow.xScale = Random
        snow.yScale = Random
        snow.rotation = math.random(1,360)
        snows:insert(snow)
    end
end

function AnimateSnow()
    SN.y = SN.y + 2
    SN.x = SN.x + 0.01
end

function DeleteSnow(SNOW)
    SNOW:removeSelf()
    SNOW = nil
end
-----------------------------------------------------------------------------------------

-- Ship Smoke --

function Smoke()
    Fires = display.newImage("Fire.png", Ship.x, math.random(Ship.y + 40 ,Ship.y + 60))
    Fires.xScale = 0.04
    Fires.yScale = 0.02
    Fires.rotation = 0
    Fire:insert(Fires)
end
function AnimateFire()
    F1.xScale = F1.xScale + 0.0007
    F1.yScale = F1.yScale + 0.0004
    F1.y = F1.y + 0.3
    F1.alpha = F1.alpha - 0.05
end

function deleteFire(index)
    F1:removeSelf()
    F1 = nil
end

-----------------------------------------------------------------------------------------

--Gen Bomb--

function GenBomb3(E2)
    BO3 = display.newImage("3.png", E2.x, E2.y)
    BO3.xScale = 1
    BO3.yScale = 1
    audio.play(BombSound)
    Bomb3:insert(BO3)
end

function AnimateBomb3()
    BB3.alpha = BB3.alpha - 0.1
    BB3.xScale = BB3.xScale + 0.001
    BB3.yScale =BB3.yScale + 0.001
end

function DeleteBomb3(F1)
    F1:removeSelf()
    F1 = nil
end
-----------------------------------------------------------------------------------------

function Esmoke()
    Fires1 = display.newImage("Fire.png", Eb1.x + 2, math.random(Eb1.y + 40 ,Eb1.y + 60))
    Fires1.xScale = 0.04
    Fires1.yScale = 0.02
    Fires1.rotation = 0
    Fire1:insert(Fires1)
end
function AnimateEfire()
    F2.xScale = F2.xScale + 0.0007
    F2.yScale = F2.yScale + 0.0004
    F2.y = F2.y - 0.3
    F2.alpha = F2.alpha - 0.05
end

function deleteEfire(F4)
    F4:removeSelf()
    F4 = nil
end

-----------------------------------------------------------------------------------------

-- Genreate Enemy--

function GenEnemie()
    Enemies = display.newImage("Enemie.png", math.random(50,300), -120 )
    Enemies.rotation = 180
    Enemies.xScale = 0.3
    Enemies.yScale = 0.3
    Enemie:insert(Enemies)
end

function AnimateEnemie()
    if powerup >= 3 then  
        E1.y = E1.y + 0.5
    else
        E1.y = E1.y + 1
    end
    if math.random(1,100) == 1 then
        GenEbullet()
    end
end

function DeleteEnemies(enemy)
    enemy:removeSelf()
    enemy = nil
end

-- Generate enemy bullet --

function GenEbullet()
    Ebullets = display.newImage("BULLET ENEMIE.png", E1.x, E1.y)
    Ebullets.xScale = 0.05
    Ebullets.yScale = 0.05
    Ebullet:insert(Ebullets)
end

function AnimateEbullet()
    if powerup >= 3 then   
        Eb1.y = Eb1.y + 2
    else
        Eb1.y = Eb1.y + 4
    end
end

function DeleteEbullet(bullet)
    bullet:removeSelf()
    bullet = nil
end
-----------------------------------------------------------------------------------------

-- Gen ship Bullet -- 

DelayBullet = 25

function GenBullet()
    Bullets = display.newImage("Laser_Bullet.png", 160, 200)
    Bullets.xScale = 0.2
    Bullets.yScale = 0.2
    Bullets.rotation = -90
    Bullets.x = Ship.x
    Bullets.y = Ship.y
    Bullet:insert(Bullets)
end

function AnimateBullet()
    B1.y = B1.y - 8
end

function DeleteBullet(bullet)
    bullet:removeSelf()
    bullet = nil
end

-----------------------------------------------------------------------------------------

-- Gen Portal --

function Genportal()
    Portal = display.newImage("Portal.png", math.random(1,300) ,math.random(300,400))
    Portal.xScale = 0.2
    Portal.yScale = 0.2
    Portal.alpha = 0.8
    Portal.rotation = 90
    audio.play(Portalsound)
    portal:insert(Portal)
end

function Animateportal()
    for index = portal.numChildren, 1, -1 do
        PO1 = portal[index]
        PO1.alpha = PO1.alpha - 0.1
        if PO1.alpha <= 0 then
            deletePortal(PO1)
        end
    end
end

function deletePortal(Portal)
    Portal:removeSelf()
    Portal = nil
end

-----------------------------------------------------------------------------------------
--Genorb--

function GenOrb()
    orb = display.newImage("DARK ORB.png", E2.x, E2.y)
    orb.xScale = 0.5
    orb.yScale = 0.5
    LaserOrb:insert(orb)
end

function AnimateOrb()
    PP.y = PP.y +0.01
end

function DeleteOrb(O1)
    O1:removeSelf()
    O1 = nil
end
-----------------------------------------------------------------------------------------

--Genlaser--

function GenLaser()
    for index = portal.numChildren, 1, -1 do
        LGA = portal[index]
        Laser = display.newImage("Laser.png", LGA.x, LGA.y - 420)
        Laser.rotation = 90
        Laser.xScale = 1
        Laser.yScale = 0.7
        audio.play(LASERSOUND)
        laser:insert(Laser)
    end
end

function Animatelaser()
    LA.alpha = LA.alpha - 0.1
end

function DeleteLaser(LA)
    LA:removeSelf()
    LA = nil
end
-----------------------------------------------------------------------------------------

--Gen Shield--

function GenShield()
    shield = display.newImage("Shield", Ship.x, Ship.y)
    shield.xScale = 0.5
    shield.yScale = 0.5
    Shield:insert(shield)
end

function AnimateShield ()
    SHE.alpha = SHE.alpha - 0.001
end

function DeleteShield(SHE)
    SHE:removeSelf()
    SHE = nil
end

function IceOrbGen()
    IceOrb = display.newImage("Iceorb.png",E1.x,E1.y)
    IceOrb.xScale = 0.5
    IceOrb.yScale = 0.5
    iceorbs:insert(IceOrb)
end

function DeleteIceOrb(SHO)
    SHO:removeSelf()
    SHO = nil
end

function SET()
    powerup = 0
end

-----------------------------------------------------------------------------------------

function panda(event)
    tapX = event.x
    tapY = event.y
end

Ship:addEventListener("tap", panda)

-----------------------------------------------------------------------------------------

function phython(event)
    if gameover == true then
        return
    end
    touchX = event.x
    touchY = event.y
    SmokeX = event.x
    SmokeY = event.y
    if event.phase == "began" then
    elseif event.phase == "moved" then
    elseif event.phase == "ended" then
    end
    Ship.x = touchX
    Ship.y = touchY
end

Runtime:addEventListener("touch", phython)

-----------------------------------------------------------------------------------------

function checkcollision(object1,object2)
    local B1 = object1
    local E2 = object2

    if B1.y < E2.y+(E2.height * E2.yScale/2) and
    B1.y > E2.y-(E2.height * E2.yScale/2) and
    B1.x < E2.x+(E2.width * E2.xScale/2) and
    B1.x > E2.x-(E2.width * E2.xScale/2) then  
        return true
    else
        return false   
    end     
end

function LockShip(A)
    local PP = A
    if PP.x <= Ship.x then
        PP.y = PP.y + 1.0
        PP.x = PP.x +0.3
    else
        PP.y = PP.y + 1.0
        PP.x = PP.x - 0.3
    end
    if PP.y >= 600 then
        DeleteOrb(PP)
    end
end
--{function Restart(number1)
    --if number1.numChildren 1, -1,then
    --local D = number1
    --D:removeSelf()
    --D = nil
--end
ENC = 80
Enemyspawn = 80
-----------------------------------------------------------------------------------------
gameover = false
points = 0
powerup = 0
score = display.newText("", 270 , -50)
Orb = 0
life = 3
function myloop(event)
    if gameover == true then
        GenGameOver()
        return
    end

    if math.random(1,2) == 1 then
        Smoke()
    end

    for index = Fire.numChildren, 1, -1 do
        F1 = Fire[index]
        AnimateFire()
        if F1.alpha <= 0 then
            deleteFire(index)
        end
    end

    DelayBullet = DelayBullet - 1
    if DelayBullet <= 0 then
        GenBullet()
        audio.play(sound)
        DelayBullet = 25
    end

    for index = Bullet.numChildren, 1, -1 do
        B1 = Bullet[index]
        AnimateBullet() 
        if B1.y <= -50 then
            DeleteBullet(B1)
        end
    end

    Enemyspawn = Enemyspawn - 1 
    if Enemyspawn <= 1 then
        GenEnemie()
        Enemyspawn = ENC
        ENC = ENC - 1
    end

    for index = Enemie.numChildren, 1, -1 do
        E1 = Enemie[index]
        AnimateEnemie()
        if E1.y >= 650 then
            DeleteEnemies(E1)
        end
        if SFF == 1 then
            GenBomb3()
            SFF = 0
        end
    end

    for index = Ebullet.numChildren, 1, -1 do
        Eb1 = Ebullet[index]
        AnimateEbullet()
        if Eb1.y >= 650 then
            DeleteEbullet(Eb1)
        end
    end

    for index = laser.numChildren, 1, -1 do
        LCH = laser[index]
    end

-----------------------------------------------------------------------------------------

    for EBCHECK = Ebullet.numChildren, 1, -1 do
        CEB = Ebullet[EBCHECK]
        if checkcollision(CEB, Ship) == true then
            gameover = true
        end
    end

-----------------------------------------------------------------------------------------

    -- POWER UP CHODE

    for OrbCheck = LaserOrb.numChildren, 1, -1 do
        OBC = LaserOrb[OrbCheck]
        if checkcollision(OBC, Ship) == true then
            DeleteOrb(OBC)
            Orb = Orb + 1
            break
        end
    end

    for ICEcheck = iceorbs.numChildren, 1, -1 do
        ICE = iceorbs[ICEcheck]
        if checkcollision(ICE, Ship) == true then
            DeleteIceOrb(ICE)
            powerup = powerup + 1
            break
        end
    end

    for index = Bomb3.numChildren, 1, -1 do
        BB3 = Bomb3[index]
        AnimateBomb3()
        if BB3.alpha <= 0 then
            DeleteBomb3(BB3)
        end
    end

    for index = iceorbs.numChildren, 1, -1 do
        II = iceorbs[index]
        LockShip(II)
        if II.y >= 600 then
            DeleteOrb(II)
        end
    end

    if powerup >= 3 then
        GenSnow()
        audio.play(SNOWS)
        timer.performWithDelay(4000,SET)
    end

    for index = snows.numChildren,1 ,-1 do
        SN = snows[index]
        AnimateSnow()
        if SN.y>= 600 then
            DeleteSnow(SN)
        end
    end

    for index = LaserOrb.numChildren, 1, -1 do
        PP = LaserOrb[index]
        LockShip(PP)
        if PP.y >= 600 then
            DeleteOrb(PP)
        end
    end

-----------------------------------------------------------------------------------------

    if Orb >= 3 then
        Orb = 0
        timer.performWithDelay(0,Genportal)
        timer.performWithDelay(200,Genportal)
        timer.performWithDelay(400,Genportal)
        timer.performWithDelay(600,Genportal)
        timer.performWithDelay(800,Genportal)
        timer.performWithDelay(1000,Genportal)
        timer.performWithDelay(1200,Genportal)
        timer.performWithDelay(1400,GenLaser)
        timer.performWithDelay(1900,AnimateLaser)
        timer.performWithDelay(2100,Animateportal)
        timer.performWithDelay(2110,Animateportal)
        timer.performWithDelay(2120,Animateportal)
        timer.performWithDelay(2130,Animateportal)
        timer.performWithDelay(2140,Animateportal)
        timer.performWithDelay(2150,Animateportal)
        timer.performWithDelay(2160,Animateportal)
        timer.performWithDelay(2170,Animateportal)
        timer.performWithDelay(2180,Animateportal)
        timer.performWithDelay(2190,Animateportal)
        timer.performWithDelay(2200,Animateportal)
    end

    for index = laser.numChildren, 1, -1 do
        LA = laser[index]
        Animatelaser()
        if LA.alpha <= 0 then
            DeleteLaser(LA)
        end
    end

    for index = laser.numChildren, 1, -1 do
        LCH1 = laser[index]
        for Enemielaser = Enemie.numChildren, 1, -1 do
            LECH = Enemie[Enemielaser]     
            if LECH.x < LCH1.x+(LCH1.width * LCH1.xScale/2) and
            LECH.x > LCH1.x-(LCH1.width * LCH1.xScale/2) then
                GenBomb3(LECH)
                DeleteEnemies(LECH)
                points = points + 10
            end
        end
    end
-----------------------------------------------------------------------------------------
--Gem--

for index = gems.numChildren, 1, -1 do
    local PP = gems[index]
    if PP.x <= Ship.x then
        PP.y = PP.y + 3.0
        PP.x = PP.x +1
    else
        PP.y = PP.y + 3.0
        PP.x = PP.x - 1
    end
    if PP.y >= 600 then
        DeleteGem(PP)
    end
end

for GemCheck = gems.numChildren, 1, -1 do
    GEMSC = gems[GemCheck]
    if checkcollision(Ship, GEMSC) == true then
        points = points + 10
        DeleteGem(GEMSC)
        audio.play(COLLECT)
    end
end

-----------------------------------------------------------------------------------------

    for Number = Bullet.numChildren, 1, -1 do
        B1 = Bullet[Number]
        for number = Enemie.numChildren,1,-1 do
            E2 = Enemie[number]
            if checkcollision(B1,E2) == true then
                GenGems(E2)
                GenBomb3(E2)
                DeleteBullet(B1)
                DeleteEnemies(E2)
                RandomAbility = math.random(1,5)
                if RandomAbility == 1 then
                    GenOrb()
                elseif RandomAbility == 5 then
                    IceOrbGen()
                end
                break
            end
        end
    end
    Shadow.x = Ship.x
    Shadow.y = Ship.y

    score.text = "SCORE: ".. points

end
Runtime:addEventListener("enterFrame", myloop)    